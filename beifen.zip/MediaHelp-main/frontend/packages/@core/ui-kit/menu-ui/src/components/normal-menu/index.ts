export type * from './normal-menu';
export { default as NormalMenu } from './normal-menu.vue';
