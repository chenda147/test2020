export { default as VbenRenderContent } from './render-content.vue';
