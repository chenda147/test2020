export { default as VbenIcon } from './icon.vue';
