export { default as VbenFullScreen } from './full-screen.vue';
