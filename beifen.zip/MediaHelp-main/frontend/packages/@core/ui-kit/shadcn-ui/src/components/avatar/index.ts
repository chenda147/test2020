export { default as VbenAvatar } from './avatar.vue';
