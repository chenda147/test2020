export { default as VbenLogo } from './logo.vue';
