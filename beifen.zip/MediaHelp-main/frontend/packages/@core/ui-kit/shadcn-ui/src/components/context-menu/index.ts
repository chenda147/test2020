export { default as VbenContextMenu } from './context-menu.vue';

export type * from './interface';
