export { default as VbenInputPassword } from './input-password.vue';
