export { default as VbenScrollbar } from './scrollbar.vue';
