export { default as VbenSegmented } from './segmented.vue';

export type * from './types';
