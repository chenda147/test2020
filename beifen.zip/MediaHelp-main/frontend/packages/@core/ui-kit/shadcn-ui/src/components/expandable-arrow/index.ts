export { default as VbenExpandableArrow } from './expandable-arrow.vue';
