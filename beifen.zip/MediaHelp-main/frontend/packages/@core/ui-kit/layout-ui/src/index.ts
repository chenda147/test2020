export type * from './vben-layout';
export { default as VbenAdminLayout } from './vben-layout.vue';
