# Simple i18n

Simple i18 implementation
