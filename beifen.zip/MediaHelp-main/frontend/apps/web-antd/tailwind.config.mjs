export { default } from '@vben/tailwind-config';
