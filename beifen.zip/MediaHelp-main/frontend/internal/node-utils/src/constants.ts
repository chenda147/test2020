enum UNICODE {
  FAILURE = '\u2716', // ✖
  SUCCESS = '\u2714', // ✔
}

export { UNICODE };
