declare module '@tailwindcss/nesting' {
  export default any;
}
