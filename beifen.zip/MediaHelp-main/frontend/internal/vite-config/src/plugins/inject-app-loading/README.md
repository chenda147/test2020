# inject-app-loading

用于在应用加载时显示加载动画的插件，可自行选择加载动画的样式。
